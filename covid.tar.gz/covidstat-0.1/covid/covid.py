import sys
import os
import requests as rt
import datetime
import pandas as pn
from matplotlib import pyplot as pl


def main():
    if (os.path.exists('covid.csv')):
       nw=os.times()[4]
       nw=datetime.datetime.fromtimestamp(nw)
       bf=os.stat('covid.csv')[9]
       bf=datetime.datetime.fromtimestamp(bf)
       df=nw-bf
       days=df.days
       secs=df.seconds
    else:
       days=1   
    if (days>0 or secs>43200):
       res=rt.get('https://opendata.ecdc.europa.eu/covid19/casedistribution/csv')
       if res.ok:
          with open('covid.csv', 'w') as f:
            f.write(res.content.decode('UTF-8'))
            print('data updated')

    r=pn.read_csv('covid.csv')
    if len(sys.argv)<2:
       print("""
       It's a Covid statistics program!
       type 'covid country'
       or 'covidstat World'
       or 'covidstat Leaders'
       
       to get country names press any key""")
       input()
       for s in r['countriesAndTerritories'].unique():
         print(s)
       sys.exit()

    cntr=sys.argv[1]

    if cntr=='Leaders':
      ri=r.groupby(['countriesAndTerritories']).sum()
      si=ri['cases'].sum()
      ri['cases']=ri['cases'].apply(lambda x: x/si)
      ri=ri.sort_values(axis=0, by=['cases'], ascending=False)
      ri=ri.head(7)
      ri=ri['cases']
      ss=ri.sum()
      ri['the Rest']=1-ss
      print(ri.map('{:.1%}'.format))
      ri.plot.pie(subplots=True, autopct='%1.1f%%')
      pl.show()
      sys.exit(0)

    elif cntr=='World':
      ri=r.groupby(['dateRep']).sum()
      ri=ri.iloc[:,[3,4]]
      ri.index=pn.to_datetime(ri.index, format='%d/%m/%Y')

    else:
      if cntr not in r['countriesAndTerritories'].unique():
         print('wrong country name')
         sys.exit(1)
      ri=r[r['countriesAndTerritories']==cntr]
      ri.index=pn.to_datetime(ri['dateRep'], format='%d/%m/%Y')
      ri=ri.iloc[:,[4,5]]


    ri=ri.sort_index(ascending=True)

    ri['total_cases']=ri['cases'].cumsum()
    ri['total_deaths']=ri['deaths'].cumsum()
    print('last 10 days:')
    print(ri.tail(4))

    ri.drop(ri.columns[1], axis=1, inplace=True)
    ri=ri[ri['total_cases']>ri['total_cases'].iloc[-1]*0.01]
    ri.plot()
    pl.title(cntr)
    pl.show()



if __name__ == '__main__':
    main()
