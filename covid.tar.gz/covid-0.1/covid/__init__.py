print('protect yourself')
