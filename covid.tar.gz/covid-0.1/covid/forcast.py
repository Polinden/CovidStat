import pandas as pn
import numpy as np
from sklearn.linear_model import ElasticNetCV
from sklearn.preprocessing import PolynomialFeatures
from sklearn import linear_model
from sklearn.pipeline import Pipeline 
from sklearn.metrics import r2_score
from matplotlib import pyplot as pl
from matplotlib.dates import DateFormatter
import datetime

import warnings
warnings.filterwarnings('ignore')




what='died'
trend=35



e=pn.read_csv('zopa.csv')
e=e.astype({e.columns[0]: 'datetime64'})
e.set_index(e.columns[0], inplace=True)



e.plot(figsize=(12,6))


# In[23]:


def dif_and_log(vals, what):
    vals.index=(vals.index-vals.index[0]).days
    vals['old']=vals[what]
    vals[what]=vals[what].diff()
    vals.dropna(inplace=True)
    vals[what]=np.log(vals[what])
    vals.replace([np.inf, -np.inf], np.nan, inplace=True)
    vals.dropna(inplace=True)
    

def hampel_filter(vals_orig, k=5, t0=2):   
        vals=vals_orig.copy()  
        L= 1.4826
        rolling_median=vals.rolling(k).median()
        difference=np.abs(rolling_median-vals)
        median_abs_deviation=difference.rolling(k).median()
        threshold= t0 *L * median_abs_deviation
        outlier_idx=difference>threshold
        vals[outlier_idx]=np.nan
        return vals.fillna(method='ffill').to_numpy()




mind=e.index[0]
dif_and_log(e, what)
x=e.index.to_numpy()[: , np.newaxis] 
y=hampel_filter(e[what])

def dode():
    """
    f,ax=pl.subplots(3,1, sharex=True, figsize=(12,6))
    ax[0].plot(x, yi['old'])
    ax[0].set_title('befor ')

    ax[1].scatter(x,yi[what])
    ax[1].set_title('after diff and log')

    ax[2].scatter(x,y)
    ax[2].set_title('after filter')
    """


# In[25]:


model = Pipeline(steps = [('polynom', PolynomialFeatures(3)), 
                          ('model', ElasticNetCV(cv=12, eps=.003, l1_ratio=[0.15 ,.25, .35, .45,], 
                                                     normalize=True))])
model.fit(x, y)
xp=np.append(x,[float(x) for x in range (int(x[-1]), int(x[-1]+trend))])
ypi = model.predict(xp[:, np.newaxis])




yp=np.cumsum(np.exp(ypi))
xp=[mind+datetime.timedelta(x) for x in xp]
sc=r2_score(y, ypi[:len(y)])




fig, ax = pl.subplots(figsize=(10,4))
ax.plot(xp[:len(x)], e['old']/1000, label='fact'); ax.plot(xp, yp/1000, 'r-', label='prediction'); 
ax.legend(loc='upper left'); ax.set_title(what+', thnd.people')
ax.tick_params(axis='x', rotation=70); ax.xaxis.set_major_formatter(DateFormatter("%m-%Y"))
ax.text(s='score: {:.2%}'.format(sc), x=0.8, y=0.1, fontsize=11, transform=ax.transAxes, bbox=dict(boxstyle='round', fc="w", ec="k"))
pl.show()




