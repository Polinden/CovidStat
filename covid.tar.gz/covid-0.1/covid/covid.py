import sys
import os
import requests as rt
import datetime
import pandas as pn
import numpy as np
import tkinter
from tkinter import ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from matplotlib import pyplot as pl
from matplotlib import dates
from matplotlib import ticker
import matplotlib.lines as pll
from matplotlib.dates import DateFormatter
from abc import ABC, abstractmethod
import itertools
from functools import lru_cache
from sklearn.linear_model import ElasticNetCV
from sklearn.preprocessing import PolynomialFeatures
from sklearn import linear_model
from sklearn.pipeline import Pipeline 
from sklearn.metrics import r2_score
import queue

import warnings
warnings.filterwarnings('ignore')



class PTable(ttk.Frame):
    """
      Table for any Pandas DataFrame
      1) header for the table 
      2) number of lines to show 
      3) wdar - array of width for columns
      4) set_data to be shown
      5) show or hide table
    """
    _WD1=110
    _WD2=90
    def __init__(self, root, header, lines=4, wdar=None):
        super().__init__(root)
        if not wdar: wdar=[self._WD1]+list(itertools.repeat(self._WD2,lines-1))
        self.table=tkinter.ttk.Treeview(self, selectmode="none", columns=header, displaycolumns=header[:-1], height=lines)
        for i,j in enumerate(header):
              self.table.column('#0{}'.format(i), anchor=tkinter.E, width=wdar[i])
              self.table.heading('#0{}'.format(i), text=j, anchor=tkinter.W)
        self.table.grid(row=0,column=0, padx=1, pady=1, sticky=tkinter.E+tkinter.W+tkinter.S+tkinter.N)
        self.my_data=[]
        self.table.grid_forget()

    def show(self):
        self.table.grid()
        self.table.delete(*self.table.get_children())
        for i in range(len(self.my_data)):
            self.table.insert('', 'end', text=self.my_data.index[i], values=tuple(self.my_data.iloc[i, 0:]))

    def hide(self):
        self.table.grid_forget()

    def set_data(self, data):
        self.my_data=data

    def set_header(self, header):
        for i,j in enumerate(header):
            self.table.heading('#0{}'.format(i), text=j, anchor=tkinter.W)


class MPanels(ttk.Notebook):
    """
      Tabs manipulation helper
      If you store this object in "tabs" variable, thnen you can do the following:
            tabs['tab_name'] -> gives list of widgets and handlers in specified tab_name
            tabs['tab_name'] <- update a dict of widgets and handlers for sa specified tab_name
            tabs['cur']  -> gives a tuple with (a list and name) for the current tab
            tabs['tab_name']['me'] -> gives a referance to the ground frame in a tab_name
                                  in order to attach children to it
    """

    class MPanel(ttk.Frame):
        def __init__(self, root):
           ttk.Frame.__init__(self, root)
           self._filds={'me':self, 'event_hdlr':None}
           self.bind("<Visibility>", self.on_visibility)

        def on_visibility(self, event):
            if self._filds['event_hdlr']: self._filds['event_hdlr'](event)

    def __init__(self, root, lst):
        ttk.Notebook.__init__(self, root)
        self.tl={}
        for p in lst:
            tabi=self.MPanel(self)
            self.add(tabi, text=p)
            tabi.columnconfigure(0, weight=0)
            tabi.columnconfigure(1, weight=0)
            self.tl[p]=tabi

    def __getitem__(self, item):
        if item in self.tl:
           return self.tl[item]._filds
        if item=='cur':
           return self.get_cur_tab()
        return super().__getitem__(item)

    def __setitem__(self, item, value):
        if item in self.tl:
           return self.tl[item]._filds.update(value)
        return super().__setitem__(item, value)

    def get_cur_tab(self):
        tab_name=self.tab(self.select(), "text")
        return self[tab_name], tab_name



class HintedPlot():
    """
      Hinted Plot for pandas data
      1) size is a matplotlib subplot size - a tuple
      2) canvas - is a place to draw it. if canvas is specified then it will be used (for updating and replacing data) 
      3) otherwise a new canvas in tkinter container "root" will be created
      4) show and hide
      5) hint_plot is used by an external event handler to place a text hint in x,y coordinates (x,y is axes coordinate, calculated by a handler)
    """
    _DPI=70
    _bg_color='#ebebeb'
    _hint=dict(pad=5, fc="gray", ec="none")
    _text=dict(pad=0.5, boxstyle='round', fc="w", ec="k")


    def __init__(self, root, size=(8,5), canvas=None):
        if not canvas:
           fig=Figure(figsize=size, dpi=self._DPI)
           fig.subplots_adjust(bottom=0.2)
           fig.patch.set_facecolor(self._bg_color)
           canvas=FigureCanvasTkAgg(fig, master=root)
        else:
           fig=canvas.figure   
        self.__dict__.update({'fig':fig, 'canvas':canvas, 'grid':canvas.get_tk_widget().grid, 'hint_plot':self.hint_plot})

    def hide(self):
        if hasattr(self, 'axes'): self.fig.delaxes(self.axes)
        return self.canvas

    def show(self, pandas_data):
        self.axes=self.fig.add_subplot(111)
        self.axes.tick_params(width=2)
        ax=pandas_data.plot(ax=self.axes, x_compat=True)
        self.text=self.axes.text(0,0, '', fontsize=12, color='white', ha='center', transform=self.axes.transAxes, bbox=self._hint)
        self.line=pll.Line2D([0,0],[0,1], transform=self.axes.transAxes)
        self.axes.yaxis.set_major_formatter(ticker.FuncFormatter(lambda x, p: format(int(x), ',')))
        self.axes.add_line(self.line)
        self.canvas.draw_idle()
        return ax

    def set_title(self, text):
        self.axes.set_title(text)

    def hint_plot(self, xy, text):
        self.line.set_xdata(xy[0])
        self.text.set_position(xy)
        self.text.set_text(text)
        self.canvas.draw_idle()

    def text_plot(self, text, x,y):
        self.axes.text(s=text, x=x, y=y, fontsize=12, transform=self.axes.transAxes, bbox=self._text)


class HintedPie(HintedPlot):
    def show(self, pandas_data):
        self.axes=self.fig.add_subplot(111)
        self.axes.tick_params(width=2)
        ax=pandas_data.plot.pie(ax=self.axes,subplots=False, autopct='%2.1f%%', labeldistance=1.07, pctdistance=0.65, startangle=125)
        [ta.set_rotation(360) for ta in ax.texts]
        self.canvas.draw_idle()
        return ax


class MFrame:
    _TABS=['Statistics', 'Forecast']
    _HEADER=['data','new','total','died']
    _HEADER_F=['rates','a=country','b=world','a/b, times']

    def __init__(self, pndata):
        self._pnd_data=pndata
        self.tk=tkinter.Tk()
        self.tk.lift()
        self.tk.wm_title("Covid Statistics")
        self.make_tabs()
        self.tk.resizable(False, False)

    def make_tabs(self):
        self.tabs=MPanels(self.tk, self._TABS)
        self.tabs.grid(row=0, column=0)
        self.make_fst_tab(self._TABS[0])
        self.make_snd_tab(self._TABS[1])

    def make_fst_tab(self,tab_name):
        self.make_plot_for_tk(tab_name)
        self.make_list(tab_name)
        self.make_buttons(tab_name)
        self.make_table(tab_name, self._HEADER)
        self.make_checks(tab_name)

    def make_snd_tab(self,tab_name):
        self.make_plot_for_tk(tab_name, False)
        self.tabs[tab_name]['event_hdlr']=self.show_forcast
        self.make_table(tab_name, self._HEADER_F)
        self.prev_fcst=None
        label=ttk.Label(self.tabs[tab_name]['me'], text='', style='L.TLabel')
        label.grid(row=3, column=1, sticky=tkinter.E+tkinter.W+tkinter.S+tkinter.N)
        ttk.Style().configure('L.TLabel', padding=(40,5,30,5), font=('Helvetica', '14') )
        self.tabs[tab_name]['label']=label

    def make_checks(self, tab_name):
        self.tabs[tab_name]['where']='cases'

    def make_table(self, tab_name, header):
        table=PTable(self.tabs[tab_name]['me'], header)
        table.grid(row=5,rowspan=7, column=1, padx=20, pady=8, sticky=tkinter.E+tkinter.W+tkinter.S+tkinter.N)
        self.tabs[tab_name]={'table':table}

    def make_plot_for_tk(self, tab_name, with_handlers=True):
        pl.style.use('seaborn-talk')
        plot=HintedPlot(self.tabs[tab_name]['me'], (11,8))
        plot.grid(rowspan=30, row=0, column=0, pady=0, padx=0, sticky=tkinter.W+tkinter.N)
        self.tabs[tab_name]={'plot':plot}
        if with_handlers:
            self.tabs[tab_name]={'handlerC':ChartEventHandler(plot.__dict__), 
                                 'handlerP':PieEventHandler({'set_country':self.set_country})}

    def make_buttons(self,tab_name):
        frm1=ttk.Frame(self.tabs[tab_name]['me'])
        frm1.columnconfigure(0, weight=1); frm1.columnconfigure(1, weight=1)
        frm1.grid(row=2,column=1, padx=10, pady=10, sticky=tkinter.E+tkinter.W+tkinter.S)
        but1=ttk.Button(frm1, text='World', style='L.TButton', command=self.world_show)
        but1.grid(row=0,column=0, padx=8, sticky=tkinter.E+tkinter.W+tkinter.S)
        but2=ttk.Button(frm1, text='Leaders',style='R.TButton', command=self.show_pie)
        but2.grid(row=0,column=1, padx=8, sticky=tkinter.E+tkinter.W+tkinter.S)
        ttk.Style().configure('R.TButton', foreground='red')

    def make_list(self,tab_name):
        self.variable = tkinter.StringVar(self.tabs[tab_name]['me'])
        self.variable.set(self._pnd_data.cntrs[0])
        lis1=ttk.Combobox(self.tabs[tab_name]['me'], textvariable=self.variable, values=list(self._pnd_data.cntrs), state='readonly',width=100)
        lis1.config(width=17)
        lis1.grid(row=1,column=1, padx=20, pady=0,sticky=tkinter.E+tkinter.W+tkinter.S+tkinter.N+tkinter.S)
        self.variable.trace("w", self.redraw_plot)

    def show_plot(self):
        m,n=self.tabs['cur']
        d=self._pnd_data.apply_visitor(ChartVisitor(m))
        self.tabs[n]={'cur_plot':m['plot']}
        e=m['cur_plot'].show(d)
        m['handlerP'].deactivate()
        m['handlerC'].activate(d,e)
        self.show_table(d)
        self.set_title()

    def show_table(self, data):
        m,n=self.tabs['cur']
        d=data.tail(4)
        d.index=d.index.strftime('%d/%m/%Y')
        d=d.applymap(lambda x: "{:,}".format(x))
        m['table'].set_data(d)
        m['table'].show()

    def show_pie(self):
        m,n=self.tabs['cur']
        self._pnd_data.cntr='Leaders'
        self.tabs[n]={'cur_plot':HintedPie(m['me'], canvas=self.flush_cur_plot())}
        e=m['cur_plot'].show(self._pnd_data.apply_visitor(PieVisitor(m)))
        m['handlerC'].deactivate()
        m['handlerP'].activate(e.patches)
        m['table'].hide()
        self.set_title('Leaders by number of cases')

    def flush_cur_plot(self):
        m,_=self.tabs['cur']
        if m['cur_plot']:
            return m['cur_plot'].hide()
        else: return None

    def world_show(self, *args):
        self._pnd_data.cntr='World'
        self.flush_cur_plot()
        self.show_plot()

    def redraw_plot(self, *args):
        self._pnd_data.cntr=self.variable.get()
        self.flush_cur_plot()
        self.show_plot()

    def set_country(self, country):
        if country in self._pnd_data.cntrs:
            self.variable.set(country)
            return True
        return False

    def set_title(self, text=None):
        m,_=self.tabs['cur']
        if not text:
           text=self._pnd_data.cntr
        m['cur_plot'].set_title(text)

    def show_forcast(self, event):
        if self.prev_fcst==self._pnd_data.cntr: return
        self.prev_fcst=self._pnd_data.cntr
        d,score,f=self.cached_sf(self._pnd_data.cntr)
        m,_=self.tabs['cur']
        m['plot'].hide()
        m['plot'].show(d)
        m['plot'].set_title('Forecast on 30 days for {}'.format(self._pnd_data.cntr))
        m['plot'].text_plot('score: {:.2%}'.format(score), x=0.82, y=0.07)
        m['plot'].text_plot(f, x=0.02, y=0.7)
        if self._pnd_data.cntr in ['World','Leaders']:
            m['table'].hide()
            m['label']['text']=''
        else:    
            
            res=self._pnd_data.apply_visitor(DiffVisitor(m))
            m['table'].set_data(res[0])            
            m['table'].show()
            m['label']['text']=f'The rates (over the population of {res[1]}M) are:'

    @lru_cache
    def cached_sf(self, name):
        m,n=self.tabs['cur']
        return self._pnd_data.apply_visitor(ForcastVisitor(m))

    def mf_quit(self):
        self.tab1.quit()
        self.tab1.destroy()


class BasicEventHandler(ABC):
    def __init__(self, filds):
        self.__dict__.update(filds)
        self.axes=None
        self.ids=[]

    def deactivate(self):
         if self.axes:
             for i in self.ids:
                 self.axes.figure.canvas.mpl_disconnect(i)

    @abstractmethod
    def activate(self, *varg):
        pass

    @abstractmethod
    def onevent(self, event):
        pass


class PieEventHandler(BasicEventHandler):
    _a1 = tuple(itertools.repeat(1,10))
    _a2 = tuple(itertools.repeat(0.6,10))
    
    def activate(self,patches):
            self.p=patches
            self.fig = self.p[0].figure
            self.ax = self.p[0].axes
            self.ids.append(self.fig.canvas.mpl_connect('button_press_event', self.onevent))
            self.ids.append(self.fig.canvas.mpl_connect("motion_notify_event", self.onhover))

    def onevent(self, event):
        if event.inaxes!=self.ax:
            return
        for w in self.p:
            (hit,_) = w.contains(event)
            if hit: 
               self.set_country(w.get_label())

    def onhover(self, event):
        if event.inaxes == self.ax:
          for i, w in enumerate(self.p):
            if w.contains_point([event.x, event.y]):
                w.set_alpha(self._a2[i])
            else:
                w.set_alpha(self._a1[i])
        self.fig.canvas.draw_idle()



class ChartEventHandler(BasicEventHandler):
    _PRE1=0.02
    _PRE2=0.98
    def activate(self, data, axes):
            self.data=data
            self.axes=axes
            self.ids.append(self.axes.figure.canvas.mpl_connect('motion_notify_event', self.onevent))

    def onevent(self, event):
        if event.inaxes:
          w=dates.num2date(event.xdata).strftime('%Y/%m/%d')
          p=self.axes.transAxes.inverted().transform((event.x,event.y))
          if p[0]>self._PRE1 and p[0]<self._PRE2:
              d=self.data[w:w]
              if len(d)>0:
                  self.hint_plot(p, d.to_string(index=False))



class Visitor(ABC):
   def __init__(self, filds):
       self.__dict__.update(filds)

   @abstractmethod
   def visit(self, data):
       pass


class PieVisitor(Visitor):
    _TOP=9
    def visit(self, data):
        if data.cntr=='Leaders': 
           ri=data.r.groupby(['countriesAndTerritories']).sum()
           si=ri[self.where].sum()
           ri[self.where]=ri[self.where].apply(lambda x: x/si)
           ri=ri.sort_values(axis=0, by=[self.where], ascending=False)
           ri=ri.head(self._TOP)
           ri=ri[self.where]
           ss=ri.sum()
           ri['the Rest']=1-ss
           ri=ri.rename('')
           return ri


class ChartVisitor(Visitor):
    def visit(self, data):
        if data.cntr=='World':
           ri=data.r.groupby(['dateRep']).sum()
           ri=ri.iloc[:,[3,4]]
           ri.index=pn.to_datetime(ri.index, format='%d/%m/%Y')
        else:
           ri=data.r[data.r['countriesAndTerritories']==data.cntr]
           ri.index=pn.to_datetime(ri['dateRep'], format='%d/%m/%Y')
           ri=ri.iloc[:,[4,5]]

        ri=ri.sort_index(ascending=True)
        ri['total']=ri['cases'].cumsum()
        ri['died']=ri['deaths'].cumsum()
        ri.drop(ri.columns[1], axis=1, inplace=True)
        ri=ri[ri['total']>ri['total'].iloc[-1]*0.01]
        ri.rename(inplace=True, columns={'cases':'new'})
        ri.index.rename('',inplace=True)
        return ri



class ForcastVisitor(ChartVisitor):
    _what='total'
    _trend=30
    def visit(self, data):
        name=data.cntr
        if name=='Leaders': name,data.cntr=data.cntr,'World'
        e=super().visit(data).copy()
        data.cntr=name
        mind=e.index[0]
        self.dif_and_log(e, self._what)
        x=e.index.to_numpy()[: , np.newaxis] 
        y=self.hampel_filter(e[self._what])
        cvc=12 if len(x)>24 else len(x)//2
        if cvc<4: raise ValueError('Not enough data!')
        model = Pipeline(steps = [('polynom', PolynomialFeatures(3)), 
                                  ('model', ElasticNetCV(cv=cvc, eps=.003, l1_ratio=[0.15 ,.25, .35, .45,], 
                                                             normalize=True, max_iter=1500))])
        model.fit(x, y)
        xp=np.append(x,[float(x) for x in range (int(x[-1]), int(x[-1]+self._trend))])
        ypi=model.predict(xp[:, np.newaxis])
        yp=self.reverse_dif(ypi)
        koef=(e['old'].iloc[-1])/yp[len(e)-1]
        yp=yp*koef
        xp=[mind+datetime.timedelta(x) for x in xp]
        d=pn.DataFrame(data={'date':xp, 'forecast':yp}).set_index('date')
        fact=e['old'].tolist()
        d['fact']=list(itertools.chain(fact, itertools.repeat(None, len(d)-len(e))))
        return (d, r2_score(fact, yp[:len(fact)]), self.in_latex(model,koef))

    def in_latex(self, model, koef=1):
        ls=r'$y=\sum_{0}^{x}{\exp{(' 
        a1=['']+model[0].get_feature_names()
        a2=np.append([model[-1].intercept_], model[-1].coef_)
        for p, w in zip(a1,a2):
           if w: 
               zs='{:+.4}*{}'.format(w*koef,p).replace('x0','x')
               if zs.find('e')>=0:
                   ls+=zs.replace('e','e^{').replace('*','}')
               else:
                   ls+=zs.replace('*','')
        return ls.replace('(+','(')+')}}$'

    def reverse_dif(sef, vals):
        return np.cumsum(np.exp(vals))

    def dif_and_log(self, vals, what):
        vals.index=(vals.index-vals.index[0]).days
        vals['old']=vals[what]
        vals[what]=vals[what].diff()
        vals.dropna(inplace=True)
        vals[what]=np.log(vals[what])
        vals.replace([np.inf, -np.inf], np.nan, inplace=True)
        vals.dropna(inplace=True)

    def hampel_filter(self, vals_orig, k=5, t0=2):
        vals=vals_orig.copy()
        L= 1.4826
        rolling_median=vals.rolling(k).median()
        difference=np.abs(rolling_median-vals)
        median_abs_deviation=difference.rolling(k).median()
        threshold= t0 *L * median_abs_deviation
        outlier_idx=difference>threshold
        vals[outlier_idx]=np.nan
        return vals.fillna(method='ffill').to_numpy()


class DiffVisitor(Visitor):
    def visit(self, data):
        contr=data.cntr
        z=data.r.groupby('countriesAndTerritories').agg({'cases':'sum','deaths':'sum','popData2018':'max'})
        tot_popul=int(z['popData2018'].sum())
        tot_infect=int(z['cases'].sum())
        tot_died=int(z['deaths'].sum())
        z=z.loc[contr,:]
        con_popul=int(z['popData2018'].sum())
        con_infect=int(z['cases'].sum())
        con_died=int(z['deaths'].sum())
        qz=data.r[data.r['countriesAndTerritories']==contr].sort_values(['year','month','day']).tail(10)
        rate1=qz['cases'].sum()/len(qz['cases'])/con_infect
        qz=data.r.groupby('dateRep').agg({'cases':'sum','day':'first','month':'first','year':'first'}).sort_values(
                ['year','month','day']).tail(10)
        rate2=qz['cases'].sum()/len(qz['cases'])/tot_infect
        zz=pn.DataFrame({contr:[con_infect/con_popul, rate1, con_died/con_popul, con_died/con_infect], 
            'Wolrd':[tot_infect/tot_popul, rate2, tot_died/tot_popul, tot_died/tot_infect]}, index=['Infected','Inftd.growth','Died','Lethality'])
        zz['Diff']=zz.iloc[:,0]/zz.iloc[:,1]
        return (zz.apply(lambda x: x.map('{:.2f}'.format) if x.name=='Diff' else x.map('{:.3%}'.format)), f'{con_popul/1000000:.2f}') 
                


class PNData:
    def __init__(self, cntr):
       self.cntr=cntr
       self.r=pn.read_csv('covid.csv')
       self.cntrs=self.r['countriesAndTerritories'].unique()
       if self.cntr not in self.cntrs:
           if self.cntr not in ['Leaders','World']: 
               print('wrong country name')
               raise ValueError()


    def apply_visitor(self, visitor: Visitor):
        return visitor.visit(self)

################################################################

def update_data_file(to, fro):
    if (os.path.exists(to)):
       nw=os.times()[4]
       nw=datetime.datetime.fromtimestamp(nw)
       bf=os.stat(to)[9]
       bf=datetime.datetime.fromtimestamp(bf)
       df=nw-bf
       days=df.days
       secs=df.seconds
    else:
       days=1
    if (days>0 or secs>43200):
       res=rt.get(fro)
       if res.ok:
          with open(to,'w') as f:
            f.write(res.content.decode('UTF-8'))
            print('data updated')






##############################################################


def main():
   try:
      update_data_file('covid.csv','https://opendata.ecdc.europa.eu/covid19/casedistribution/csv')
      cntr='World' if len(sys.argv)<2 else sys.argv[1]
      pnd=PNData(cntr)
      if cntr=='Leaders':
           mf=MFrame(pnd).show_pie()
      else:
           mf=MFrame(pnd).show_plot()
      tkinter.mainloop()
   except Exception as e:
       print(e.args)
       exit(1)


if __name__ == '__main__':
    main()
