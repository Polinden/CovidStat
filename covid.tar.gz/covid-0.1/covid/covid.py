import sys
import os
import requests as rt
import datetime
import pandas as pn
from matplotlib import pyplot as pl
import tkinter
from matplotlib.backends.backend_tkagg import (
    FigureCanvasTkAgg, NavigationToolbar2Tk)
from matplotlib.figure import Figure
from abc import ABC, abstractmethod
import matplotlib.ticker as ticker



class MFrame:
    def __init__(self, pndata):
        self.pnd=pndata
        self.root = tkinter.Tk()
        self.root.wm_title("Covid Statistics")
        self.make_plot_for_tk()
        self.make_list()
        self.root.resizable(False, False)

    def make_plot_for_tk(self):
        pl.style.use('seaborn-talk')
        self.fig=Figure(figsize=(11, 8), dpi=70)
        self.fig.subplots_adjust(bottom=0.2)
        self.canvas=FigureCanvasTkAgg(self.fig, master=self.root)
        self.axis=self.fig.add_subplot(111)
        self.axis.tick_params(width=2)
        self.canvas.get_tk_widget().grid(rowspan=30, row=0, column=0, pady=0, padx=0, sticky=tkinter.W+tkinter.N)
 
    def make_plot(self):
        self.pnd.apply_visitor(ChartVisitor(self.axis, self.lab1))
        self.axis.set_title(self.pnd.cntr)
        self.axis.yaxis.set_major_formatter(ticker.FuncFormatter(lambda x, p: format(int(x), ',')))
        self.canvas.draw_idle()

    def make_list(self):
        self.variable = tkinter.StringVar(self.root)
        self.variable.set(self.pnd.cntrs[-1])
        lis1=tkinter.OptionMenu(self.root, self.variable, *self.pnd.cntrs)
        lis1.config(width=25)
        self.root.columnconfigure(0, weight=0)
        self.root.columnconfigure(1, weight=0)
        lis1.grid(row=1,column=1, padx=20, pady=5, sticky=tkinter.E+tkinter.W+tkinter.S)
        self.variable.trace("w", self.redraw)
        but1=tkinter.Button(self.root, text='World', command=self.world_show)
        but1.config(width=25)
        but1.grid(row=2,column=1, padx=20, pady=5, sticky=tkinter.E+tkinter.W+tkinter.S)
        but2=tkinter.Button(self.root, text='Leaders', command=self.make_pie)
        but2.config(width=25)
        but2.grid(row=3,column=1, padx=20, pady=5, sticky=tkinter.E+tkinter.W+tkinter.S)
        frm1=tkinter.LabelFrame(self.root,text='Recently',highlightbackground="gray", highlightthickness=2, relief=tkinter.SUNKEN)
        frm1.grid(row=6,rowspan=11, column=1, padx=20, pady=10, sticky=tkinter.E+tkinter.W+tkinter.S+tkinter.N)
        self.lab1=tkinter.Message(frm1, width=300, justify=tkinter.RIGHT)
        self.lab1.config(font=('arial', 13))
        self.lab1.grid(row=0,column=0, padx=4, pady=4, sticky=tkinter.E+tkinter.S+tkinter.N)


    def world_show(self, *args):
        self.pnd.cntr='World'
        self.fig.delaxes(self.axis)
        self.axis=self.fig.add_subplot(111)
        self.make_plot()

    def redraw(self, *args):
        self.pnd.cntr=self.variable.get()
        self.fig.delaxes(self.axis)
        self.axis=self.fig.add_subplot(111)
        self.make_plot()

    def make_pie(self):
        self.pnd.cntr='Leaders'
        self.fig.delaxes(self.axis)
        self.axis=self.fig.add_subplot(111)
        self.pnd.apply_visitor(PieVisitor(self.axis, self.lab1))
        self.axis.set_title('Leaders by total cases')
        self.canvas.draw_idle()

    def _quit(self):
        self.root.quit()
        self.root.destroy()




def chck_time():
    if (os.path.exists('covid.csv')):
       nw=os.times()[4]
       nw=datetime.datetime.fromtimestamp(nw)
       bf=os.stat('covid.csv')[9]
       bf=datetime.datetime.fromtimestamp(bf)
       df=nw-bf
       days=df.days
       secs=df.seconds
    else:
       days=1
    if (days>0 or secs>43200):
       res=rt.get('https://opendata.ecdc.europa.eu/covid19/casedistribution/csv')
       if res.ok:
          with open('covid.csv', 'w') as f:
            f.write(res.content.decode('UTF-8'))
            print('data updated')



class Visitor(ABC):
   def __init__(self, axis,mes):
       self.axis=axis
       self.message=mes

   @abstractmethod
   def visit(self, data):
       pass


class PieVisitor(Visitor):
    def visit(self, data):
        if data.cntr=='Leaders':
           ri=data.r.groupby(['countriesAndTerritories']).sum()
           si=ri['cases'].sum()
           ri['cases']=ri['cases'].apply(lambda x: x/si)
           ri=ri.sort_values(axis=0, by=['cases'], ascending=False)
           ri=ri.head(7)
           ri=ri['cases']
           ss=ri.sum()
           ri['the Rest']=1-ss
           print(ri.map('{:.1%}'.format))
           ri=ri.rename('')
           ri.plot.pie(ax=self.axis,subplots=False,autopct='%1.1f%%')
           self.message['text']="""This is a Covid-19 statistics program. 
Be caraful. 
Wash your hands. 
Take a responsibility"""


class ChartVisitor(Visitor):
    def visit(self, data):
        if data.cntr=='World':
           ri=data.r.groupby(['dateRep']).sum()
           ri=ri.iloc[:,[3,4]]
           ri.index=pn.to_datetime(ri.index, format='%d/%m/%Y')

        else:
           ri=data.r[data.r['countriesAndTerritories']==data.cntr]
           ri.index=pn.to_datetime(ri['dateRep'], format='%d/%m/%Y')
           ri=ri.iloc[:,[4,5]]

        ri=ri.sort_index(ascending=True)
        ri['total_cases']=ri['cases'].cumsum()
        ri['total_deaths']=ri['deaths'].cumsum()
        print('last 10 days:')
        print(ri.tail(4))

        ri.drop(ri.columns[1], axis=1, inplace=True)
        ri=ri[ri['total_cases']>ri['total_cases'].iloc[-1]*0.01]
        ri.rename(inplace=True, columns={'cases':'new','total_cases':'total','total_deaths':'died'})
        ri.index.rename('',inplace=True)
        ri.plot(ax=self.axis)
        self.message['text']=ri.tail(4).to_string().replace('2020-','').replace('-','/')


class PNData:
    def __init__(self, cntr):
       self.cntr=cntr
       self.r=pn.read_csv('covid.csv')
       self.cntrs=self.r['countriesAndTerritories'].unique()
       if self.cntr not in self.cntrs:
           if self.cntr not in ['Leaders','World']: 
               print('wrong country name')
               raise ValueError()


    def apply_visitor(self, visitor: Visitor):
        visitor.visit(self)

##############################################################


def main():
    chck_time()
    if len(sys.argv)<2: 
        cntr='World'
    else:
        cntr=sys.argv[1]

    try:  
       pnd=PNData(cntr) 
       if cntr=='Leaders':
           mf=MFrame(pnd).make_pie()
       else:
         mf=MFrame(pnd).make_plot()
       tkinter.mainloop()
    except ValueError:
       exit(1)  


if __name__ == '__main__':
    main()
