import sys
import os
import requests as rt
import datetime
import pandas as pn
from matplotlib import pyplot as pl
from matplotlib import dates
import matplotlib.lines
import tkinter
from matplotlib.backends.backend_tkagg import (
    FigureCanvasTkAgg, NavigationToolbar2Tk)
from matplotlib.figure import Figure
from abc import ABC, abstractmethod
import matplotlib.ticker as ticker
from tkinter import ttk
import itertools



class Table4DF(tkinter.Frame):
    _WD1,_WD2=110,90
    def __init__(self, root, header):
        super().__init__(root)
        self.table=tkinter.ttk.Treeview(self, selectmode="none", columns=header, displaycolumns=header[:-1], height=4)
        wdar=[self._WD1]; wdar.extend(itertools.repeat(self._WD2,len(header)-1))
        for i,j in enumerate(header):
              self.table.column('#0{}'.format(i), anchor=tkinter.E, width=wdar[i])
              self.table.heading('#0{}'.format(i), text=j, anchor=tkinter.W)
        self.table.grid(row=0,column=0, padx=1, pady=1, sticky=tkinter.E+tkinter.W+tkinter.S+tkinter.N)
        self.my_data=[]
        self.table.grid_forget()


    def show(self):
        self.table.grid()
        self.table.delete(*self.table.get_children())
        for i in range(len(self.my_data)):
            self.table.insert('', 'end', text=self.my_data.index[i], values=tuple(self.my_data.iloc[i, 0:]))

    def hide(self):
        self.table.grid_forget()

    def update(self, data):
        self.my_data=data


class MFrame:
    def __init__(self, pndata):
        self.pnd=pndata
        self.root = tkinter.Tk()
        self.root.wm_title("Covid Statistics")
        self.root.columnconfigure(0, weight=0)
        self.root.columnconfigure(1, weight=0)
        self.make_plot_for_tk()
        self.make_list()
        self.make_buttons()
        self.table=Table4DF(self.root,['data','new','total','died'])
        self.table.grid(row=6,rowspan=10, column=1, padx=20, pady=10, sticky=tkinter.E+tkinter.W+tkinter.S+tkinter.N)
        self.handlerP=PieEventHandler(self)
        self.handlerC=ChartEventHandler(self)
        self.root.resizable(False, False)

    def make_plot_for_tk(self):
        pl.style.use('seaborn-talk')
        self.fig=Figure(figsize=(11, 8), dpi=70)
        self.fig.subplots_adjust(bottom=0.2)
        self.canvas=FigureCanvasTkAgg(self.fig, master=self.root)
        self.axes=self.fig.add_subplot(111)
        self.axes.tick_params(width=2)
        self.canvas.get_tk_widget().grid(rowspan=30, row=0, column=0, pady=0, padx=0, sticky=tkinter.W+tkinter.N)

    def make_buttons(self):
        but1=tkinter.Button(self.root, text='World', command=self.world_show)
        but1.config(width=25)
        but1.grid(row=2,column=1, padx=20, pady=5, sticky=tkinter.E+tkinter.W+tkinter.S)
        but2=tkinter.Button(self.root, text='Leaders', command=self.show_pie)
        but2.config(width=25)
        but2.grid(row=3,column=1, padx=20, pady=5, sticky=tkinter.E+tkinter.W+tkinter.S)

    def make_list(self):
        self.variable = tkinter.StringVar(self.root)
        self.variable.set(self.pnd.cntrs[0])
        lis1=ttk.Combobox(self.root, textvariable=self.variable, values=list(self.pnd.cntrs), state='readonly',width=100)
        lis1.config(width=25)
        lis1.grid(row=1,column=1, padx=20, pady=5, sticky=tkinter.E+tkinter.W+tkinter.S)
        self.variable.trace("w", self.redraw_plot)

    def show_plot(self):
        self.pnd.apply_visitor(ChartVisitor(self))
        self.axes.set_title(self.pnd.cntr)
        self.axes.yaxis.set_major_formatter(ticker.FuncFormatter(lambda x, p: format(int(x), ',')))
        bbox=dict(pad=3, fc="gray", ec="none")
        self.text=self.axes.text(0,0, '', fontsize=12, color='white', ha='center', transform=self.axes.transAxes, bbox=bbox)
        self.line=matplotlib.lines.Line2D([0,0],[0,1], transform=self.axes.transAxes)
        self.axes.add_line(self.line)
        self.canvas.draw_idle()

    def show_pie(self):
        self.pnd.cntr='Leaders'
        self.fig.delaxes(self.axes)
        self.axes=self.fig.add_subplot(111)
        self.pnd.apply_visitor(PieVisitor(self))
        self.axes.set_title('Leaders by total cases')
        self.canvas.draw_idle()   

    def world_show(self, *args):
        self.pnd.cntr='World'
        self.fig.delaxes(self.axes)
        self.axes=self.fig.add_subplot(111)
        self.show_plot()

    def redraw_plot(self, *args):
        self.pnd.cntr=self.variable.get()
        self.fig.delaxes(self.axes)
        self.axes=self.fig.add_subplot(111)
        self.show_plot()

    def hint_plot(self, xy, text):
          self.text.set_position(xy)
          self.text.set_text(text)
          self.line.set_xdata(xy[0])
          self.axes.figure.canvas.draw()

    def set_contry(self, country):
        if country in self.pnd.cntrs:
            self.variable.set(country)
            return True
        return False

    def mf_quit(self):
        self.root.quit()
        self.root.destroy()


class BasicEventHandler(ABC):
    def __init__(self, frame):
        self.frame=frame
        self.axes=None

    def deactivate(self):
         if self.axes:
            self.axes.figure.canvas.mpl_disconnect(self.id)

    @abstractmethod
    def activate(self, *varg):
        pass

    @abstractmethod
    def onevent(self, event):
        pass


class PieEventHandler(BasicEventHandler):
    def activate(self,patches):
            self.p=patches
            self.fig = self.p[0].figure
            self.ax = self.p[0].axes
            self.id=self.fig.canvas.mpl_connect('button_press_event', self.onevent)

    def onevent(self, event):
        if event.inaxes!=self.ax:
            return
        for w in self.p:
            (hit,_) = w.contains(event)
            if hit and self.frame.set_contry(w.get_label()):
               self.frame.redraw_plot()



class ChartEventHandler(BasicEventHandler):
    _PRE1=0.02
    _PRE2=0.98
    def activate(self, data, axes):
            self.data=data
            self.axes=axes
            self.id=self.axes.figure.canvas.mpl_connect('motion_notify_event', self.onevent)

    def onevent(self, event):
        if event.inaxes:
          w=dates.num2date(event.xdata).strftime('%Y/%m/%d')
          p=self.axes.transAxes.inverted().transform((event.x,event.y))
          if p[0]>self._PRE1 and p[0]<self._PRE2:
              d=self.data[w:w]
              if len(d)>0:
                  self.frame.hint_plot(p, d.to_string(index=False))



class Visitor(ABC):
   def __init__(self, frame):
       self.handlerC=frame.handlerC
       self.handlerP=frame.handlerP
       self.axes=frame.axes
       self.table=frame.table

   @abstractmethod
   def visit(self, data):
       pass


class PieVisitor(Visitor):
    _TOP=7
    def visit(self, data):
        if data.cntr=='Leaders':
           ri=data.r.groupby(['countriesAndTerritories']).sum()
           si=ri['cases'].sum()
           ri['cases']=ri['cases'].apply(lambda x: x/si)
           ri=ri.sort_values(axis=0, by=['cases'], ascending=False)
           ri=ri.head(self._TOP)
           ri=ri['cases']
           ss=ri.sum()
           ri['the Rest']=1-ss
           ri=ri.rename('')
           e=ri.plot.pie(ax=self.axes,subplots=False,autopct='%1.1f%%')

           self.handlerC.deactivate()
           self.handlerP.activate(e.patches)
           self.table.hide()


class ChartVisitor(Visitor):
    def visit(self, data):
        if data.cntr=='World':
           ri=data.r.groupby(['dateRep']).sum()
           ri=ri.iloc[:,[3,4]]
           ri.index=pn.to_datetime(ri.index, format='%d/%m/%Y')
        else:
           ri=data.r[data.r['countriesAndTerritories']==data.cntr]
           ri.index=pn.to_datetime(ri['dateRep'], format='%d/%m/%Y')
           ri=ri.iloc[:,[4,5]]

        ri=ri.sort_index(ascending=True)
        ri['total']=ri['cases'].cumsum()
        ri['died']=ri['deaths'].cumsum()
        ri.drop(ri.columns[1], axis=1, inplace=True)
        ri=ri[ri['total']>ri['total'].iloc[-1]*0.01]
        ri.rename(inplace=True, columns={'cases':'new'})
        ri.index.rename('',inplace=True)
        e=ri.plot(ax=self.axes, x_compat=True)

        self.handlerP.deactivate()
        self.handlerC.activate(ri,e)

        ri=ri.tail(4)
        ri.index=ri.index.strftime('%d/%m/%Y')
        ri=ri.applymap(lambda x: "{:,}".format(x))
        self.table.update(ri)
        self.table.show()



class PNData:
    def __init__(self, cntr):
       self.cntr=cntr
       self.r=pn.read_csv('covid.csv')
       self.cntrs=self.r['countriesAndTerritories'].unique()
       if self.cntr not in self.cntrs:
           if self.cntr not in ['Leaders','World']: 
               print('wrong country name')
               raise ValueError()


    def apply_visitor(self, visitor: Visitor):
        visitor.visit(self)

################################################################

def update_data_file(to, fro):
    if (os.path.exists(to)):
       nw=os.times()[4]
       nw=datetime.datetime.fromtimestamp(nw)
       bf=os.stat(to)[9]
       bf=datetime.datetime.fromtimestamp(bf)
       df=nw-bf
       days=df.days
       secs=df.seconds
    else:
       days=1
    if (days>0 or secs>43200):
       res=rt.get(fro)
       if res.ok:
          with open(to,'w') as f:
            f.write(res.content.decode('UTF-8'))
            print('data updated')






##############################################################


def main():
    update_data_file('covid.csv','https://opendata.ecdc.europa.eu/covid19/casedistribution/csv')
    cntr='World' if len(sys.argv)<2 else sys.argv[1]
    try:
       pnd=PNData(cntr)
       if cntr=='Leaders':
           mf=MFrame(pnd).show_pie()
       else:
           mf=MFrame(pnd).show_plot()
       tkinter.mainloop()
    except ValueError:
       exit(1)


if __name__ == '__main__':
    main()
