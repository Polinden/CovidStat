import sys
import os
import requests as rt
import datetime
import pandas as pn
from matplotlib import pyplot as pl
from matplotlib import dates
import matplotlib.lines
import tkinter
from matplotlib.backends.backend_tkagg import (
    FigureCanvasTkAgg, NavigationToolbar2Tk)
from matplotlib.figure import Figure
from abc import ABC, abstractmethod
import matplotlib.ticker as ticker
from tkinter import ttk
import itertools



class Table4DF(ttk.Frame):
    """
      Table for any Pandas DataFrame
      1) __init__ gets a header for the table
      2) update sets up the data
      3) show and hide
      4) _WD1,_WD2 - width of the fst and the other columns
    """

    _WD1,_WD2=110,90
    def __init__(self, root, header):
        super().__init__(root)
        self.table=tkinter.ttk.Treeview(self, selectmode="none", columns=header, displaycolumns=header[:-1], height=4)
        wdar=[self._WD1]; wdar.extend(itertools.repeat(self._WD2,len(header)-1))
        for i,j in enumerate(header):
              self.table.column('#0{}'.format(i), anchor=tkinter.E, width=wdar[i])
              self.table.heading('#0{}'.format(i), text=j, anchor=tkinter.W)
        self.table.grid(row=0,column=0, padx=1, pady=1, sticky=tkinter.E+tkinter.W+tkinter.S+tkinter.N)
        self.my_data=[]
        self.table.grid_forget()


    def show(self):
        self.table.grid()
        self.table.delete(*self.table.get_children())
        for i in range(len(self.my_data)):
            self.table.insert('', 'end', text=self.my_data.index[i], values=tuple(self.my_data.iloc[i, 0:]))

    def hide(self):
        self.table.grid_forget()

    def update(self, data):
        self.my_data=data


class MPanals(ttk.Notebook):
    """
      Tabs manipulation helper
      for syntax: tabs['name'] -> gives list of widgets and handlers in specified tab
            tabs['name'] <- update a dict of widgets and handlers for sa specified tab
            tabs['cur']  -> gives a tuple with (a list and name) for the current tab
            tabs['name']['me'] -> gives a referance to the ground frame in a tab
                                  in order to attach children to it
    """

    class MPanel(ttk.Frame):
        def __init__(self, root):
           ttk.Frame.__init__(self, root)
           self._elms={'me':self, 'event_hdlr':None}
           self.bind("<Visibility>", self.on_visibility)

        def on_visibility(self, event):
            print(self._elms['me'])
            if self._elms['event_hdlr']: event_hdlr(event)

    def __init__(self, root, lst):
        ttk.Notebook.__init__(self, root)
        self.tl={}
        for p in lst:
            tabi=self.MPanel(self)
            self.add(tabi, text=p)
            tabi.columnconfigure(0, weight=0)
            tabi.columnconfigure(1, weight=0)
            self.tl[p]=tabi

    def __getitem__(self, item):
        if item in self.tl:
           return self.tl[item]._elms
        if item=='cur':
           return self.get_cur_tab()
        return super().__getitem__(item)

    def __setitem__(self, item, value):
        if item in self.tl:
           return self.tl[item]._elms.update(value)
        return super().__setitem__(item, value)

    def get_cur_tab(self):
        tab_name=self.tab(self.select(), "text")
        return self[tab_name], tab_name




class MFrame:
    _TABS=['Statistics', 'Forecast']
    def __init__(self, pndata):
        self.pnd=pndata
        self.tk=tkinter.Tk()
        self.tk.wm_title("Covid Statistics")
        self.make_tabs()
        self.tk.resizable(False, False)

    def make_tabs(self):
        self.tabs=MPanals(self.tk, self._TABS)
        self.tabs.grid(row=0, column=0)
        self.make_fst_tab(self._TABS[0])
        self.make_snd_tab(self._TABS[1])

    def make_fst_tab(self,tab_name):
        self.make_plot_for_tk(tab_name)
        self.make_list(tab_name)
        self.make_buttons(tab_name)
        self.make_table(tab_name)
        self.tabs[tab_name]={'handlerP':PieEventHandler(self.tabs[tab_name])}
        self.tabs[tab_name]={'handlerC':ChartEventHandler(self.tabs[tab_name])}

    def make_snd_tab(self,tab_name):
        self.make_plot_for_tk(tab_name)
        self.tabs[tab_name]={'handlerP':PieEventHandler(self.tabs[tab_name])}

    def make_table(self,tab_name):
        table=Table4DF(self.tabs[tab_name]['me'],['data','new','total','died'])
        table.grid(row=5,rowspan=7, column=1, padx=20, pady=8, sticky=tkinter.E+tkinter.W+tkinter.S+tkinter.N)
        self.tabs[tab_name]={'table':table}

    def make_plot_for_tk(self, tab_name):
        pl.style.use('seaborn-talk')
        fig=Figure(figsize=(11, 8), dpi=70)
        fig.subplots_adjust(bottom=0.2)
        canvas=FigureCanvasTkAgg(fig, master=self.tabs[tab_name]['me'])
        axes=fig.add_subplot(111)
        axes.tick_params(width=2)
        canvas.get_tk_widget().grid(rowspan=30, row=0, column=0, pady=0, padx=0, sticky=tkinter.W+tkinter.N)
        self.tabs[tab_name]={'axes':axes, 'fig':fig, 'canvas':canvas,'set_country':self.set_country, 'hint_plot':self.hint_plot}

    def make_buttons(self,tab_name):
        frm1=ttk.Frame(self.tabs[tab_name]['me'])
        frm1.columnconfigure(0, weight=1)
        frm1.columnconfigure(1, weight=1)
        frm1.grid(row=2,column=1, padx=10, pady=10, sticky=tkinter.E+tkinter.W+tkinter.S)
        but1=ttk.Button(frm1, text='World', style='L.TButton', command=self.world_show)
        but1.grid(row=0,column=0, padx=8, sticky=tkinter.E+tkinter.W+tkinter.S)
        but2=ttk.Button(frm1, text='Leaders',style='R.TButton', command=self.show_pie)
        but2.grid(row=0,column=1, padx=8, sticky=tkinter.E+tkinter.W+tkinter.S)
        ttk.Style().configure('R.TButton', foreground='red')

    def make_list(self,tab_name):
        self.variable = tkinter.StringVar(self.tabs[tab_name]['me'])
        self.variable.set(self.pnd.cntrs[0])
        lis1=ttk.Combobox(self.tabs[tab_name]['me'], textvariable=self.variable, values=list(self.pnd.cntrs), state='readonly',width=100)
        lis1.config(width=17)
        lis1.grid(row=1,column=1, padx=20, pady=0,sticky=tkinter.E+tkinter.W+tkinter.S+tkinter.N+tkinter.S)
        self.variable.trace("w", self.redraw_plot)

    def show_plot(self):
        m,n=self.tabs['cur']
        self.pnd.apply_visitor(ChartVisitor(m))
        m['axes'].set_title(self.pnd.cntr)
        m['axes'].yaxis.set_major_formatter(ticker.FuncFormatter(lambda x, p: format(int(x), ',')))
        bbox=dict(pad=3, fc="gray", ec="none")
        text=m['axes'].text(0,0, '', fontsize=12, color='white', ha='center', transform=m['axes'].transAxes, bbox=bbox)
        line=matplotlib.lines.Line2D([0,0],[0,1], transform=m['axes'].transAxes)
        m['axes'].add_line(line)
        m['canvas'].draw_idle()
        self.tabs[n]={'line':line, 'text':text}

    def show_pie(self):
        m,n=self.tabs['cur']
        self.pnd.cntr='Leaders'
        m['fig'].delaxes(m['axes'])
        m['axes']=m['fig'].add_subplot(111)
        self.pnd.apply_visitor(PieVisitor(m))
        m['axes'].set_title('Leaders by total cases')
        m['canvas'].draw_idle()   

    def world_show(self, *args):
        m,n=self.tabs['cur']
        self.pnd.cntr='World'
        m['fig'].delaxes(m['axes'])
        m['axes']=m['fig'].add_subplot(111)
        self.show_plot()

    def redraw_plot(self, *args):
        m,n=self.tabs['cur']
        self.pnd.cntr=self.variable.get()
        m['fig'].delaxes(m['axes'])
        m['axes']=m['fig'].add_subplot(111)
        self.show_plot()

    def hint_plot(self, xy, text):
          m,n=self.tabs['cur']
          m['text'].set_position(xy)
          m['text'].set_text(text)
          m['line'].set_xdata(xy[0])
          m['axes'].figure.canvas.draw()

    def set_country(self, country):
        if country in self.pnd.cntrs:
            self.variable.set(country)
            return True
        return False

    def mf_quit(self):
        self.tab1.quit()
        self.tab1.destroy()


class BasicEventHandler(ABC):
    def __init__(self, elms):
        self.__dict__.update(elms)
        self.axes=None
        self.ids=[]

    def deactivate(self):
         if self.axes:
             for i in self.ids:
                 self.axes.figure.canvas.mpl_disconnect(i)

    @abstractmethod
    def activate(self, *varg):
        pass

    @abstractmethod
    def onevent(self, event):
        pass


class PieEventHandler(BasicEventHandler):
    _a1 = tuple(itertools.repeat(1,8))
    _a2 = tuple(itertools.repeat(0.6,8))
    
    def activate(self,patches):
            self.p=patches
            self.fig = self.p[0].figure
            self.ax = self.p[0].axes
            self.ids.append(self.fig.canvas.mpl_connect('button_press_event', self.onevent))
            self.ids.append(self.fig.canvas.mpl_connect("motion_notify_event", self.onhover))

    def onevent(self, event):
        if event.inaxes!=self.ax:
            return
        for w in self.p:
            (hit,_) = w.contains(event)
            if hit: 
               self.set_country(w.get_label())

    def onhover(self, event):
        if event.inaxes == self.ax:
          for i, w in enumerate(self.p):
            if w.contains_point([event.x, event.y]):
                w.set_alpha(self._a2[i])
            else:
                w.set_alpha(self._a1[i])
        self.fig.canvas.draw_idle()



class ChartEventHandler(BasicEventHandler):
    _PRE1=0.02
    _PRE2=0.98
    def activate(self, data, axes):
            self.data=data
            self.axes=axes
            self.ids.append(self.axes.figure.canvas.mpl_connect('motion_notify_event', self.onevent))

    def onevent(self, event):
        if event.inaxes:
          w=dates.num2date(event.xdata).strftime('%Y/%m/%d')
          p=self.axes.transAxes.inverted().transform((event.x,event.y))
          if p[0]>self._PRE1 and p[0]<self._PRE2:
              d=self.data[w:w]
              if len(d)>0:
                  self.hint_plot(p, d.to_string(index=False))



class Visitor(ABC):
   def __init__(self, elms):
       self.__dict__.update(elms)

   @abstractmethod
   def visit(self, data):
       pass


class PieVisitor(Visitor):
    _TOP=7
    def visit(self, data):
        if data.cntr=='Leaders': 
           ri=data.r.groupby(['countriesAndTerritories']).sum()
           si=ri['cases'].sum()
           ri['cases']=ri['cases'].apply(lambda x: x/si)
           ri=ri.sort_values(axis=0, by=['cases'], ascending=False)
           ri=ri.head(self._TOP)
           ri=ri['cases']
           ss=ri.sum()
           ri['the Rest']=1-ss
           ri=ri.rename('')
           e=ri.plot.pie(ax=self.axes,subplots=False,autopct='%1.1f%%')

           self.handlerC.deactivate()
           self.handlerP.activate(e.patches)
           self.table.hide()


class ChartVisitor(Visitor):
    def visit(self, data):
        if data.cntr=='World':
           ri=data.r.groupby(['dateRep']).sum()
           ri=ri.iloc[:,[3,4]]
           ri.index=pn.to_datetime(ri.index, format='%d/%m/%Y')
        else:
           ri=data.r[data.r['countriesAndTerritories']==data.cntr]
           ri.index=pn.to_datetime(ri['dateRep'], format='%d/%m/%Y')
           ri=ri.iloc[:,[4,5]]

        ri=ri.sort_index(ascending=True)
        ri['total']=ri['cases'].cumsum()
        ri['died']=ri['deaths'].cumsum()
        ri.drop(ri.columns[1], axis=1, inplace=True)
        ri=ri[ri['total']>ri['total'].iloc[-1]*0.01]
        ri.rename(inplace=True, columns={'cases':'new'})
        ri.index.rename('',inplace=True)
        e=ri.plot(ax=self.axes, x_compat=True)
        ri.to_csv('zopa.csv')

        self.handlerP.deactivate()
        self.handlerC.activate(ri,e)

        ri=ri.tail(4)
        ri.index=ri.index.strftime('%d/%m/%Y')
        ri=ri.applymap(lambda x: "{:,}".format(x))
        self.table.update(ri)
        self.table.show()



class PNData:
    def __init__(self, cntr):
       self.cntr=cntr
       self.r=pn.read_csv('covid.csv')
       self.cntrs=self.r['countriesAndTerritories'].unique()
       if self.cntr not in self.cntrs:
           if self.cntr not in ['Leaders','World']: 
               print('wrong country name')
               raise ValueError()


    def apply_visitor(self, visitor: Visitor):
        visitor.visit(self)

################################################################

def update_data_file(to, fro):
    if (os.path.exists(to)):
       nw=os.times()[4]
       nw=datetime.datetime.fromtimestamp(nw)
       bf=os.stat(to)[9]
       bf=datetime.datetime.fromtimestamp(bf)
       df=nw-bf
       days=df.days
       secs=df.seconds
    else:
       days=1
    if (days>0 or secs>43200):
       res=rt.get(fro)
       if res.ok:
          with open(to,'w') as f:
            f.write(res.content.decode('UTF-8'))
            print('data updated')






##############################################################


def main():
    update_data_file('covid.csv','https://opendata.ecdc.europa.eu/covid19/casedistribution/csv')
    cntr='World' if len(sys.argv)<2 else sys.argv[1]
    try:
       pnd=PNData(cntr)
       if cntr=='Leaders':
           mf=MFrame(pnd).show_pie()
       else:
           mf=MFrame(pnd).show_plot()
       tkinter.mainloop()
    except ValueError:
       exit(1)


if __name__ == '__main__':
    main()
