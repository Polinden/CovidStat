import sys
import os
import requests as rt
import datetime
import pandas as pn
from matplotlib import pyplot as pl
import tkinter
from matplotlib.backends.backend_tkagg import (
    FigureCanvasTkAgg, NavigationToolbar2Tk)
from matplotlib.figure import Figure



class MFrame:
    def __init__(self, pndata):
        self.pnd=pndata
        self.root = tkinter.Tk()
        self.root.wm_title("Covid Statistics")
        self.fig=Figure(figsize=(8, 7), dpi=95)
        self.canvas=FigureCanvasTkAgg(self.fig, master=self.root)
        self.axis=self.fig.add_subplot(111)
        self.canvas.get_tk_widget().grid(rowspan=30, row=0, column=0, pady=0, padx=0, sticky=tkinter.W+tkinter.N)
        self.make_list()
 
    def make_figure(self):
        self.pnd.show_data().plot(ax=self.axis)
        self.axis.set_title(self.pnd.cntr)
        #for tick in self.fig.axes[0].get_xticklabels():
        #   tick.set_rotation(50)
        #   tick.set_size(7)
        self.canvas.draw_idle()

    def make_list(self):
        self.variable = tkinter.StringVar(self.root)
        self.variable.set(self.pnd.cntrs[-1])
        lis1=tkinter.OptionMenu(self.root, self.variable, *self.pnd.cntrs)
        lis1.config(width=25)
        self.root.columnconfigure(0, weight=0)
        self.root.columnconfigure(1, weight=10)
        lis1.grid(row=1,column=1, padx=20, pady=5, sticky=tkinter.E+tkinter.W+tkinter.S)
        self.variable.trace("w", self.redraw)
        but1=tkinter.Button(self.root, text='World', command=self.allshow)
        but1.config(width=25)
        but1.grid(row=2,column=1, padx=20, pady=5, sticky=tkinter.E+tkinter.W+tkinter.S)
        but2=tkinter.Button(self.root, text='Leaders', command=self.make_pie)
        but2.config(width=25)
        but2.grid(row=3,column=1, padx=20, pady=5, sticky=tkinter.E+tkinter.W+tkinter.S)

    def allshow(self, *args):
        self.pnd.cntr='World'
        self.fig.delaxes(self.axis)
        self.axis=self.fig.add_subplot(111)
        self.make_figure()

    def redraw(self, *args):
        self.pnd.cntr=self.variable.get()
        self.fig.delaxes(self.axis)
        self.axis=self.fig.add_subplot(111)
        self.make_figure()

    def make_pie(self):
        self.pnd.cntr='Leaders'
        self.fig.delaxes(self.axis)
        self.axis=self.fig.add_subplot(111)
        self.pnd.show_data().plot.pie(ax=self.axis,subplots=True,autopct='%1.1f%%')
        self.axis.set_title('Leaders by total cases')
        self.canvas.draw_idle()

    def _quit(self):
        self.root.quit()
        self.root.destroy()




def chck_time():
    if (os.path.exists('covid.csv')):
       nw=os.times()[4]
       nw=datetime.datetime.fromtimestamp(nw)
       bf=os.stat('covid.csv')[9]
       bf=datetime.datetime.fromtimestamp(bf)
       df=nw-bf
       days=df.days
       secs=df.seconds
    else:
       days=1
    if (days>0 or secs>43200):
       res=rt.get('https://opendata.ecdc.europa.eu/covid19/casedistribution/csv')
       if res.ok:
          with open('covid.csv', 'w') as f:
            f.write(res.content.decode('UTF-8'))
            print('data updated')


class PNData:
    def __init__(self, cntr):
       self.cntr=cntr
       self.r=pn.read_csv('covid.csv')
       self.cntrs=self.r['countriesAndTerritories'].unique()
       if self.cntr not in self.cntrs:
           if self.cntr not in ['Leaders','World']: 
               print('wrong country name')
               raise ValueError()
       else:
           print("""
           It's a Covid statistics program!
           type 'covid country'
           or 'covidstat World'
           or 'covidstat Leaders'
           
           to get country names press any key""")
           input()
           for s in cntrs:
             print(s)
           raise ValueError()


    def show_data(self):
        if self.cntr=='Leaders':
           ri=self.r.groupby(['countriesAndTerritories']).sum()
           si=ri['cases'].sum()
           ri['cases']=ri['cases'].apply(lambda x: x/si)
           ri=ri.sort_values(axis=0, by=['cases'], ascending=False)
           ri=ri.head(7)
           ri=ri['cases']
           ss=ri.sum()
           ri['the Rest']=1-ss
           print(ri.map('{:.1%}'.format))
           return ri

        elif self.cntr=='World':
           ri=self.r.groupby(['dateRep']).sum()
           ri=ri.iloc[:,[3,4]]
           ri.index=pn.to_datetime(ri.index, format='%d/%m/%Y')

        else:
           ri=self.r[self.r['countriesAndTerritories']==self.cntr]
           ri.index=pn.to_datetime(ri['dateRep'], format='%d/%m/%Y')
           ri=ri.iloc[:,[4,5]]

        ri=ri.sort_index(ascending=True)
        ri['total_cases']=ri['cases'].cumsum()
        ri['total_deaths']=ri['deaths'].cumsum()
        print('last 10 days:')
        print(ri.tail(4))

        ri.drop(ri.columns[1], axis=1, inplace=True)
        ri=ri[ri['total_cases']>ri['total_cases'].iloc[-1]*0.01]
        ri.rename(inplace=True, columns={'cases':'cases_per_day'})
        return ri


##############################################################


def main():
    chck_time()
    if len(sys.argv)<2: 
        cntr='World'
    else:
        cntr=sys.argv[1]

    try:  
       pnd=PNData(cntr) 
       if cntr=='Leaders':
           mf=MFrame(pnd).make_pie()
       else:
         mf=MFrame(pnd).make_figure()
       tkinter.mainloop()
    except ValueError:
       exit(1)  


if __name__ == '__main__':
    main()
