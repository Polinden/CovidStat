import setuptools

setuptools.setup(
    name="covid",
    version="0.1",
    author="denis",
    author_email="prox@i.ua",
    packages=setuptools.find_packages(),
    install_requires=['pandas>=1.0.3','requests','matplotlib','sklearn>=0.0', 'numpy>=1.18.2', 'pillow>=7.1.2'],
    python_requires='>=3.8',
    entry_points={
    'console_scripts': [
        'covidstat=covid.covid:main',
      ],
    }
)
