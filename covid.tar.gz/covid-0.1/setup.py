import setuptools

setuptools.setup(
    name="covid",
    version="0.1",
    author="denis",
    author_email="prox@i.ua",
    packages=setuptools.find_packages(),
    install_requires=['pandas','requests','matplotlib','sklearn', 'numpy'],
    python_requires='>=3.8',
    entry_points={
    'console_scripts': [
        'covidstat=covid.covid:main',
      ],
    }
)
